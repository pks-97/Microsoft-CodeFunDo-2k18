        var but = document.getElementById("but");
        var email = document.getElementById("exampleInputEmail1");
        var pwd = document.getElementById("exampleInputPassword1");
        function openWin(){
        //     var container1 = document.getElementById("container1");
        //     var child = container1.childNodes;
        //     var  i = 0;
        //     while(i<child.length){
        //         d.push([child[i].value,child[i+1].value]);
        //         c.push(child[i+2].value);
        //         i = i + 4;
        //     }
        // for(var i=0;i<c.length;i++){
        //     console.log(d[i][0],d[i][1]);
        //
        if(email.value==="Microsoft@hotmail.com" && pwd.value=="codefundo"){
            window.open("localhost:5000/solve");
        } 
        else{
            console.log("failed")
        }

    }