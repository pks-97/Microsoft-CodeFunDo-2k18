    function position (latitude,longitude) {
      this.latitude = latitude;
      this.longitude = longitude;
      this.getInfo = getPositionInfo;
    }


    function getPositionInfo() {
    return this.latitude + ',' + this.longitude;
    }

    var inputPoints = [[new position(25.2677,82.9913),
              new position(25.2886,83.0068), 
              new position(25.3324,82.9690)],
            [new position(25.2703,83.0249),
            new position(25.2762,83.0327),
            new position(25.3452,83.0187)],
            [new position(25.3163,82.9730),
            new position(25.3111,82.9864),
            new position(25.3109,83.0107)]];

    var map;

  function initMap() {

    var directionsService = new google.maps.DirectionsService();

        map = new google.maps.Map(document.getElementById('map'));

        var markers = []

        var counter = 0;

        bounds  = new google.maps.LatLngBounds();

        for(var i=0;i<inputPoints.length;i++){
          counter = 0;
          for(var j=0;j<inputPoints[i].length;j++){
            markers[counter++] = new google.maps.Marker({
          position: new google.maps.LatLng(inputPoints[i][j].latitude, inputPoints[i][j].longitude),
          label: ""+counter,
          map: map,
          });
          bounds.extend(new google.maps.LatLng(inputPoints[i][j].latitude, inputPoints[i][j].longitude));
        }
      }

      map.fitBounds(bounds);
      map.panToBounds(bounds); 

      for(var i=0;i<inputPoints.length;i++){
        for(var j=0;j<inputPoints[i].length-1;j++){
          var directionsDisplay = new google.maps.DirectionsRenderer({map: map, suppressMarkers: true,preserveViewport: true});
          calcRoute(directionsService,directionsDisplay,i,j,j+1);
          // directionsDisplay.setMap(map);
        }
      }
    }


  function calcRoute(directionsService,directionsDisplay,i,ori,dest) {
    
    var request = {
      origin: new google.maps.LatLng(inputPoints[i][ori].latitude, inputPoints[i][ori].longitude),
      destination: new google.maps.LatLng(inputPoints[i][dest].latitude,inputPoints[i][dest].longitude),
      travelMode: 'DRIVING'
    };
    
    directionsService.route(request, function(response, status) {
      if (status == 'OK') {
        directionsDisplay.setDirections(response);
      } 
    });
  }




// <input type="text" id="member" name="member" value="">Number of members: (max. 10)<br />
// <a href="#" id="filldetails" onclick="addFields()">Fill Details</a>
//     <div id="container">
//     <div id = "container1"> </div>
//     </div>

//     <button id="butt">Submit</button> 
