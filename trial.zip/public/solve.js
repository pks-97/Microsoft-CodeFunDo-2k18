
/* All required datatypes for converting code :
	
	-> vector  ---- Inbuilt in Javascript
	-> pairs   ---- Created as "pair"
	-> vector of pairs  ---- Everything is an object
	-> pair of pairs ---- Everything is an object
	-> vector of vector ---- Everything is an object
	-> map ---- Taking advantage of inbuilt dictionary funcionality

*/

//         Helper Code begins


// Mimicking the pair datatype in C++
class pair {
	constructor(first,second) {

		this.first = first;
		this.second = second;
	}
}

// Creating custom arrays
function createArray(length) {
    var arr = new Array(length || 0),
        i = length;

    if (arguments.length > 1) {
        var args = Array.prototype.slice.call(arguments, 1);
        while(i--) arr[length-1 - i] = createArray.apply(this, args);
    }

    return arr;
}

function comparator(x,y) {
	
	return x.first - y.first;
}
//                 Helper code ends

function calcD(routes,coordinates,depot_x,depot_y) {

	var cost = 0.0;

	var i;

	for(i=1;i<routes.size();i++)
	{
		var temp1 = (coordinates[routes[x]].first - coordinates[routes[x-1]].first)*(coordinates[routes[x]].first - coordinates[routes[x-1]].first);
		var temp2 = (coordinates[routes[x]].second - coordinates[routes[x-1]].second)*(coordinates[routes[x]].second - coordinates[routes[x-1]].second);

		cost += Math.sqrt(temp1 + temp2);
	}

	var temp1 = (coordinates[routes[0]].first - depot_x)*(coordinates[routes[0]].first - depot_x);
	var temp2 = (coordinates[routes[0]].second - depot_y)*(coordinates[routes[0]].second - depot_y);

	cost += Math.sqrt(temp1+temp2);

	temp1 = (coordinates[routes[routes.size()-1]].first - depot_x)*(coordinates[routes[routes.size()-1]].first - depot_x);
	temp2 = (coordinates[routes[routes.size()-1]].second - depot_y)*(coordinates[routes[routes.size()-1]].second - depot_y);

	cost += Math.sqrt(temp1+temp2);

	return cost;
}

function findDemandroute(route, demands) {
	
	var demand = 0;

	var x;

	for(x=0;x<route.size();x++)
	{
		demand += demands[route[x]];
	}

	return demand;
}



function CVRP_solve(coordinates,depot_x,depot_y,vehicle_capacity,demands,N) {

	var weight = {};
	var mark_negative = {};

	var temp = createArray(N);
	var cost_matrix = createArray(N,N);

	var x = 0;
	var i = 0;
	var j = 0;

	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			cost_matrix[i][j] = Math.sqrt(((coordinates[i].first - coordinates[j].first)*(coordinates[i].first - coordinates[j].first))+((coordinates[i].second-coordinates[j].second)*(coordinates[i].second-coordinates[j].second)));
			cost_matrix[j][i] = Math.sqrt(((coordinates[i].first - coordinates[j].first)*(coordinates[i].first - coordinates[j].first))+((coordinates[i].second-coordinates[j].second)*(coordinates[i].second-coordinates[j].second)));
		}
	}

	var savings_vector = [];
	var depot2node = createArray(N);

	for(i=0;i<N;i++)
	{
		var dist_i;
		var dist_j;
		var savings;

		for(j=i+1;j<N;j++)
		{
			dist_i = Math.sqrt(((coordinates[i].first - depot_x)*(coordinates[i].first - depot_x))+((coordinates[i].second - depot_y)*(coordinates[i].second - depot_y)));
			dist_j = Math.sqrt(((coordinates[j].first - depot_x)*(coordinates[j].first - depot_x))+((coordinates[j].second - depot_y)*(coordinates[j].second - depot_y)));

			//console.log(dist_i,dist_j);
			depot2node[i] = dist_i;

			savings = dist_i+dist_j - cost_matrix[i][j];

			node_savings = new pair(savings, new pair(i,j));

			savings_vector.push(node_savings);

		}
	}

	savings_vector.sort(comparator).reverse();
	
	var t=0;
	for(t=0;t<savings_vector.length;t++)
	{
		//console.log(savings_vector[t].first,savings_vector[t].second.first, savings_vector[t].second.second);
	}

	var visited = {};
	var interior = {};
	var index = {};

	for(x=0;x<=10000;x++)
	{
		mark_negative[x] = -1;
		visited[x] = 0;
		interior[x] = 0;
		index[x] = 0;
		weight[x] = 0;
	}

	var count = 0;
	var route_index = 0;

	var routes = createArray(1000,0);
	
	for(x=0;x<savings_vector.length;x++) {

		
		if(count>=(savings_vector.length/2))
		{
			break;
		}

		var node_i = savings_vector[x].second.first;
		var node_j = savings_vector[x].second.second;



		if(visited[node_i]==0 && visited[node_j]==0)
		{
			if(weight[route_index]<=vehicle_capacity)
			{

				route_index+=1;

				routes[route_index].push(savings_vector[x].second);

				mark_negative[route_index]=0;

				count+=2;

				weight[route_index]+=(demands[node_i]+demands[node_j]);

				visited[node_i]+=1;
				visited[node_j]+=1;

				index[node_i] = route_index;
				index[node_j] = route_index;
			}
		}
		else if(visited[node_i]==0)
		{
			if(interior[node_j]==0)
			{
				if((weight[index[node_j]]+demands[node_i])<=vehicle_capacity)
				{
					routes[index[node_j]].push(savings_vector[x].second);

					weight[index[node_j]]+=demands[node_i];

					interior[node_j]+=1;

					index[node_i] = index[node_j];

					count+=1;

					visited[node_i]+=1;
				}
			}
		}
		else if(visited[node_j]==0)
		{
			if(interior[node_i]==0)
			{
				if((weight[index[node_i]]+demands[node_j])<=vehicle_capacity)
				{
					routes[index[node_i]].push(savings_vector[x].second);

					weight[index[node_i]]+=demands[node_j];

					interior[node_i]+=1;

					index[node_j] = index[node_i];

					count+=1;

					visited[node_j]+=1;
				}
			}
		}
		else
		{
			if(interior[node_i]==0 && interior[node_j]==0 && index[node_i]!=index[node_j])
			{
				if((weight[index[node_i]]+weight[index[node_j]])<=vehicle_capacity)
				{
					weight[index[node_i]]+=weight[index[node_j]];

					mark_negative[index[node_j]]=-1;

					var temp = index[node_j];

					var k=0;

					for(k=0;k<routes[temp].length;k++)
					{
						routes[index[node_i]].push(routes[temp][k]);

						index[routes[temp][k].first] = index[node_i];
						index[routes[temp][k].second] = index[node_i];
					}

					var self = new pair();

					self.first = node_i;
					self.second = node_j;

					routes[index[node_i]].push(self);

					interior[node_i]+=1;
					interior[node_j]+=1;
				}
			}
		}
	}

	var mod_routes = [];

	var m = 0;

	for(m=0;m<routes.length;m++)
	{
		if(mark_negative[m]!=-1)
		{
			var route = [];
			var mymap = {};

			var connect = {};

			var bakchodi = 0;

			for(bakchodi=0;bakchodi<10000;bakchodi++)
			{
				mymap[bakchodi] = 0;

				var aurbakchodi = createArray(0);

				connect[bakchodi] = aurbakchodi;

			}

			var start;

			var w = 0;

			for(w=0;w<routes[m].length;w++)
			{
				mymap[routes[m][w].first]+=1;

				mymap[routes[m][w].second]+=1;
			}

			for(w=0;w<routes[m].length;w++)
			{
				if(mymap[(routes[m][w]).first]==1)
				{
					start = (routes[m][w]).first;
					break;
				}

				if(mymap[(routes[m][w]).second]==1)
				{
					start = (routes[m][w]).second;
					break;
				}
			}

			for(w=0;w<routes[m].length;w++)
			{
				connect[(routes[m][w]).first].push((routes[m][w]).second);
				connect[(routes[m][w]).second].push((routes[m][w]).first);
			}

			route.push(start);

			var temp = connect[start][0];

			while(true)
			{

				route.push(temp);

				if(mymap[temp]==1)
				{
					break;
				}

				if(connect[temp][0] == start)
				{
					start = temp;

					temp = connect[temp][1];
				}
				else
				{
					start = temp;

					temp = connect[temp][0];
				}
			}

			mod_routes.push(route);


		}
	}

	var mark = {};

	for(x=0;x<mod_routes.length;x++)
	{
		var k = 0;
		for(k=0;k<mod_routes[x].length;k++)
		{
			mark[mod_routes[x][k]]+=1;
		}
	}

	for(x=0;x<N;x++)
	{
		if(mark[x]==0)
		{
			var temp = [];

			temp.push(x);

			mod_routes.push(temp);
		}
	}

	var startx;
	var starty;
	var endx;
	var endy;
	var cost = 0;
	for(x=0;x<mod_routes.length;x++)
	{
		startx = coordinates[mod_routes[x][0]].first;
		starty = coordinates[mod_routes[x][0]].second;

		endx = coordinates[mod_routes[x][mod_routes[x].length-1]].first;
		endy = coordinates[mod_routes[x][mod_routes[x].length-1]].second;

		cost += Math.sqrt(((startx - depot_x)*(startx - depot_x)) + ((starty - depot_y)*(starty - depot_y)));
		cost += Math.sqrt(((endx - depot_x)*(endx - depot_x)) + ((endy - depot_y)*(endy - depot_y)));

		var k =1;

		for(k=1;k<mod_routes[x].length;k++)
		{
			cost+=cost_matrix[mod_routes[x][k]][mod_routes[x][k-1]];
		}
	}


	return mod_routes;


}


//               Main code begin

var N = 31;

var coordinates = [];

coordinates.push(new pair(96,44));
coordinates.push(new pair(50, 5));
coordinates.push(new pair(49, 8));
coordinates.push(new pair(13, 7));
coordinates.push(new pair(29, 89));
coordinates.push(new pair(58, 30));
coordinates.push(new pair(84, 39));
coordinates.push(new pair(14, 24));
coordinates.push(new pair(2, 39));
coordinates.push(new pair(3, 82));
coordinates.push(new pair(5, 10));
coordinates.push(new pair(98, 52));
coordinates.push(new pair(84, 25));
coordinates.push(new pair(61, 59));
coordinates.push(new pair(1, 65));
coordinates.push(new pair(88, 51));
coordinates.push(new pair(91, 2));
coordinates.push(new pair(19, 32));
coordinates.push(new pair(93, 3));
coordinates.push(new pair(50, 93));
coordinates.push(new pair(98, 14));
coordinates.push(new pair(5, 42));
coordinates.push(new pair(42, 9));
coordinates.push(new pair(61, 62));
coordinates.push(new pair(9, 97));
coordinates.push(new pair(80, 55));
coordinates.push(new pair(57, 69));
coordinates.push(new pair(23, 15));
coordinates.push(new pair(20, 70));
coordinates.push(new pair(85, 60));
coordinates.push(new pair(98, 5));


var vehicle_capacity = 100;

var demands = [];

demands.push(19);
demands.push(21);
demands.push(6);
demands.push(19);
demands.push(7);
demands.push(12);
demands.push(16);
demands.push(6);
demands.push(16);
demands.push(8);
demands.push(14);
demands.push(21);
demands.push(16);
demands.push(3);
demands.push(22);
demands.push(18);
demands.push(19);
demands.push(1);
demands.push(24);
demands.push(8);
demands.push(12);
demands.push(4);
demands.push(8);
demands.push(24);
demands.push(24);
demands.push(2);
demands.push(20);
demands.push(15);
demands.push(2);
demands.push(14);
demands.push(9);

var depot_x = 82;
var depot_y = 76;


var routes = CVRP_solve(coordinates,depot_x,depot_y,vehicle_capacity,demands,N);

console.log(routes);

















CVRP.js
Displaying CVRP.js